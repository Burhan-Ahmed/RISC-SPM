/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Bwork/DSD/CEP/RISC SPM/RISC/mux_5channel.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static int ng3[] = {2, 0};
static int ng4[] = {3, 0};
static int ng5[] = {4, 0};
static unsigned int ng6[] = {4294967295U, 4294967295U};



static void Cont_16_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[8];
    char t35[8];
    char t40[8];
    char t41[8];
    char t43[8];
    char t72[8];
    char t77[8];
    char t78[8];
    char t80[8];
    char t109[8];
    char t114[8];
    char t115[8];
    char t117[8];
    char t146[8];
    char t151[8];
    char t152[8];
    char t154[8];
    char t183[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    char *t34;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t42;
    char *t44;
    char *t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    char *t58;
    char *t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    char *t65;
    char *t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    char *t71;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t79;
    char *t81;
    char *t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    char *t95;
    char *t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    char *t102;
    char *t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    char *t107;
    char *t108;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    char *t116;
    char *t118;
    char *t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    char *t132;
    char *t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    char *t139;
    char *t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    char *t144;
    char *t145;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    char *t153;
    char *t155;
    char *t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    char *t169;
    char *t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    char *t176;
    char *t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    char *t181;
    char *t182;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    char *t188;
    char *t189;
    char *t190;
    char *t191;
    char *t192;
    unsigned int t193;
    unsigned int t194;
    char *t195;
    unsigned int t196;
    unsigned int t197;
    char *t198;
    unsigned int t199;
    unsigned int t200;
    char *t201;

LAB0:    t1 = (t0 + 3304U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(16, ng0);
    t2 = (t0 + 2144U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t2 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t2);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t4, 0, 8);
    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t22) != 0)
        goto LAB10;

LAB11:    t29 = (t4 + 4);
    t30 = *((unsigned int *)t4);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB12;

LAB13:    t36 = *((unsigned int *)t4);
    t37 = (~(t36));
    t38 = *((unsigned int *)t29);
    t39 = (t37 || t38);
    if (t39 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t29) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t40, 8);

LAB20:    t188 = (t0 + 3704);
    t189 = (t188 + 56U);
    t190 = *((char **)t189);
    t191 = (t190 + 56U);
    t192 = *((char **)t191);
    memset(t192, 0, 8);
    t193 = 255U;
    t194 = t193;
    t195 = (t3 + 4);
    t196 = *((unsigned int *)t3);
    t193 = (t193 & t196);
    t197 = *((unsigned int *)t195);
    t194 = (t194 & t197);
    t198 = (t192 + 4);
    t199 = *((unsigned int *)t192);
    *((unsigned int *)t192) = (t199 | t193);
    t200 = *((unsigned int *)t198);
    *((unsigned int *)t198) = (t200 | t194);
    xsi_driver_vfirst_trans(t188, 0, 7);
    t201 = (t0 + 3624);
    *((int *)t201) = 1;

LAB1:    return;
LAB6:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    t28 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB11;

LAB12:    t33 = (t0 + 1344U);
    t34 = *((char **)t33);
    memcpy(t35, t34, 8);
    goto LAB13;

LAB14:    t33 = (t0 + 2144U);
    t42 = *((char **)t33);
    t33 = ((char*)((ng2)));
    memset(t43, 0, 8);
    t44 = (t42 + 4);
    t45 = (t33 + 4);
    t46 = *((unsigned int *)t42);
    t47 = *((unsigned int *)t33);
    t48 = (t46 ^ t47);
    t49 = *((unsigned int *)t44);
    t50 = *((unsigned int *)t45);
    t51 = (t49 ^ t50);
    t52 = (t48 | t51);
    t53 = *((unsigned int *)t44);
    t54 = *((unsigned int *)t45);
    t55 = (t53 | t54);
    t56 = (~(t55));
    t57 = (t52 & t56);
    if (t57 != 0)
        goto LAB24;

LAB21:    if (t55 != 0)
        goto LAB23;

LAB22:    *((unsigned int *)t43) = 1;

LAB24:    memset(t41, 0, 8);
    t59 = (t43 + 4);
    t60 = *((unsigned int *)t59);
    t61 = (~(t60));
    t62 = *((unsigned int *)t43);
    t63 = (t62 & t61);
    t64 = (t63 & 1U);
    if (t64 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t59) != 0)
        goto LAB27;

LAB28:    t66 = (t41 + 4);
    t67 = *((unsigned int *)t41);
    t68 = *((unsigned int *)t66);
    t69 = (t67 || t68);
    if (t69 > 0)
        goto LAB29;

LAB30:    t73 = *((unsigned int *)t41);
    t74 = (~(t73));
    t75 = *((unsigned int *)t66);
    t76 = (t74 || t75);
    if (t76 > 0)
        goto LAB31;

LAB32:    if (*((unsigned int *)t66) > 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t41) > 0)
        goto LAB35;

LAB36:    memcpy(t40, t77, 8);

LAB37:    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 32, t35, 32, t40, 32);
    goto LAB20;

LAB18:    memcpy(t3, t35, 8);
    goto LAB20;

LAB23:    t58 = (t43 + 4);
    *((unsigned int *)t43) = 1;
    *((unsigned int *)t58) = 1;
    goto LAB24;

LAB25:    *((unsigned int *)t41) = 1;
    goto LAB28;

LAB27:    t65 = (t41 + 4);
    *((unsigned int *)t41) = 1;
    *((unsigned int *)t65) = 1;
    goto LAB28;

LAB29:    t70 = (t0 + 1504U);
    t71 = *((char **)t70);
    memcpy(t72, t71, 8);
    goto LAB30;

LAB31:    t70 = (t0 + 2144U);
    t79 = *((char **)t70);
    t70 = ((char*)((ng3)));
    memset(t80, 0, 8);
    t81 = (t79 + 4);
    t82 = (t70 + 4);
    t83 = *((unsigned int *)t79);
    t84 = *((unsigned int *)t70);
    t85 = (t83 ^ t84);
    t86 = *((unsigned int *)t81);
    t87 = *((unsigned int *)t82);
    t88 = (t86 ^ t87);
    t89 = (t85 | t88);
    t90 = *((unsigned int *)t81);
    t91 = *((unsigned int *)t82);
    t92 = (t90 | t91);
    t93 = (~(t92));
    t94 = (t89 & t93);
    if (t94 != 0)
        goto LAB41;

LAB38:    if (t92 != 0)
        goto LAB40;

LAB39:    *((unsigned int *)t80) = 1;

LAB41:    memset(t78, 0, 8);
    t96 = (t80 + 4);
    t97 = *((unsigned int *)t96);
    t98 = (~(t97));
    t99 = *((unsigned int *)t80);
    t100 = (t99 & t98);
    t101 = (t100 & 1U);
    if (t101 != 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t96) != 0)
        goto LAB44;

LAB45:    t103 = (t78 + 4);
    t104 = *((unsigned int *)t78);
    t105 = *((unsigned int *)t103);
    t106 = (t104 || t105);
    if (t106 > 0)
        goto LAB46;

LAB47:    t110 = *((unsigned int *)t78);
    t111 = (~(t110));
    t112 = *((unsigned int *)t103);
    t113 = (t111 || t112);
    if (t113 > 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t103) > 0)
        goto LAB50;

LAB51:    if (*((unsigned int *)t78) > 0)
        goto LAB52;

LAB53:    memcpy(t77, t114, 8);

LAB54:    goto LAB32;

LAB33:    xsi_vlog_unsigned_bit_combine(t40, 32, t72, 32, t77, 32);
    goto LAB37;

LAB35:    memcpy(t40, t72, 8);
    goto LAB37;

LAB40:    t95 = (t80 + 4);
    *((unsigned int *)t80) = 1;
    *((unsigned int *)t95) = 1;
    goto LAB41;

LAB42:    *((unsigned int *)t78) = 1;
    goto LAB45;

LAB44:    t102 = (t78 + 4);
    *((unsigned int *)t78) = 1;
    *((unsigned int *)t102) = 1;
    goto LAB45;

LAB46:    t107 = (t0 + 1664U);
    t108 = *((char **)t107);
    memcpy(t109, t108, 8);
    goto LAB47;

LAB48:    t107 = (t0 + 2144U);
    t116 = *((char **)t107);
    t107 = ((char*)((ng4)));
    memset(t117, 0, 8);
    t118 = (t116 + 4);
    t119 = (t107 + 4);
    t120 = *((unsigned int *)t116);
    t121 = *((unsigned int *)t107);
    t122 = (t120 ^ t121);
    t123 = *((unsigned int *)t118);
    t124 = *((unsigned int *)t119);
    t125 = (t123 ^ t124);
    t126 = (t122 | t125);
    t127 = *((unsigned int *)t118);
    t128 = *((unsigned int *)t119);
    t129 = (t127 | t128);
    t130 = (~(t129));
    t131 = (t126 & t130);
    if (t131 != 0)
        goto LAB58;

LAB55:    if (t129 != 0)
        goto LAB57;

LAB56:    *((unsigned int *)t117) = 1;

LAB58:    memset(t115, 0, 8);
    t133 = (t117 + 4);
    t134 = *((unsigned int *)t133);
    t135 = (~(t134));
    t136 = *((unsigned int *)t117);
    t137 = (t136 & t135);
    t138 = (t137 & 1U);
    if (t138 != 0)
        goto LAB59;

LAB60:    if (*((unsigned int *)t133) != 0)
        goto LAB61;

LAB62:    t140 = (t115 + 4);
    t141 = *((unsigned int *)t115);
    t142 = *((unsigned int *)t140);
    t143 = (t141 || t142);
    if (t143 > 0)
        goto LAB63;

LAB64:    t147 = *((unsigned int *)t115);
    t148 = (~(t147));
    t149 = *((unsigned int *)t140);
    t150 = (t148 || t149);
    if (t150 > 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t140) > 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t115) > 0)
        goto LAB69;

LAB70:    memcpy(t114, t151, 8);

LAB71:    goto LAB49;

LAB50:    xsi_vlog_unsigned_bit_combine(t77, 32, t109, 32, t114, 32);
    goto LAB54;

LAB52:    memcpy(t77, t109, 8);
    goto LAB54;

LAB57:    t132 = (t117 + 4);
    *((unsigned int *)t117) = 1;
    *((unsigned int *)t132) = 1;
    goto LAB58;

LAB59:    *((unsigned int *)t115) = 1;
    goto LAB62;

LAB61:    t139 = (t115 + 4);
    *((unsigned int *)t115) = 1;
    *((unsigned int *)t139) = 1;
    goto LAB62;

LAB63:    t144 = (t0 + 1824U);
    t145 = *((char **)t144);
    memcpy(t146, t145, 8);
    goto LAB64;

LAB65:    t144 = (t0 + 2144U);
    t153 = *((char **)t144);
    t144 = ((char*)((ng5)));
    memset(t154, 0, 8);
    t155 = (t153 + 4);
    t156 = (t144 + 4);
    t157 = *((unsigned int *)t153);
    t158 = *((unsigned int *)t144);
    t159 = (t157 ^ t158);
    t160 = *((unsigned int *)t155);
    t161 = *((unsigned int *)t156);
    t162 = (t160 ^ t161);
    t163 = (t159 | t162);
    t164 = *((unsigned int *)t155);
    t165 = *((unsigned int *)t156);
    t166 = (t164 | t165);
    t167 = (~(t166));
    t168 = (t163 & t167);
    if (t168 != 0)
        goto LAB75;

LAB72:    if (t166 != 0)
        goto LAB74;

LAB73:    *((unsigned int *)t154) = 1;

LAB75:    memset(t152, 0, 8);
    t170 = (t154 + 4);
    t171 = *((unsigned int *)t170);
    t172 = (~(t171));
    t173 = *((unsigned int *)t154);
    t174 = (t173 & t172);
    t175 = (t174 & 1U);
    if (t175 != 0)
        goto LAB76;

LAB77:    if (*((unsigned int *)t170) != 0)
        goto LAB78;

LAB79:    t177 = (t152 + 4);
    t178 = *((unsigned int *)t152);
    t179 = *((unsigned int *)t177);
    t180 = (t178 || t179);
    if (t180 > 0)
        goto LAB80;

LAB81:    t184 = *((unsigned int *)t152);
    t185 = (~(t184));
    t186 = *((unsigned int *)t177);
    t187 = (t185 || t186);
    if (t187 > 0)
        goto LAB82;

LAB83:    if (*((unsigned int *)t177) > 0)
        goto LAB84;

LAB85:    if (*((unsigned int *)t152) > 0)
        goto LAB86;

LAB87:    memcpy(t151, t181, 8);

LAB88:    goto LAB66;

LAB67:    xsi_vlog_unsigned_bit_combine(t114, 32, t146, 32, t151, 32);
    goto LAB71;

LAB69:    memcpy(t114, t146, 8);
    goto LAB71;

LAB74:    t169 = (t154 + 4);
    *((unsigned int *)t154) = 1;
    *((unsigned int *)t169) = 1;
    goto LAB75;

LAB76:    *((unsigned int *)t152) = 1;
    goto LAB79;

LAB78:    t176 = (t152 + 4);
    *((unsigned int *)t152) = 1;
    *((unsigned int *)t176) = 1;
    goto LAB79;

LAB80:    t181 = (t0 + 1984U);
    t182 = *((char **)t181);
    memcpy(t183, t182, 8);
    goto LAB81;

LAB82:    t181 = ((char*)((ng6)));
    goto LAB83;

LAB84:    xsi_vlog_unsigned_bit_combine(t151, 32, t183, 32, t181, 32);
    goto LAB88;

LAB86:    memcpy(t151, t183, 8);
    goto LAB88;

}


extern void work_m_00000000001007872583_2253363517_init()
{
	static char *pe[] = {(void *)Cont_16_0};
	xsi_register_didat("work_m_00000000001007872583_2253363517", "isim/Testing_isim_beh.exe.sim/work/m_00000000001007872583_2253363517.didat");
	xsi_register_executes(pe);
}
